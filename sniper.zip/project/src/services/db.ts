import { openDB, DBSchema, IDBPDatabase } from 'idb';
import { User, Bounty } from '../types';

interface WhoopDB extends DBSchema {
  users: {
    key: string;
    value: User;
    indexes: {
      'by-email': string;
      'by-role': string;
    };
  };
  bounties: {
    key: string;
    value: Bounty;
    indexes: {
      'by-status': string;
      'by-creator': string;
    };
  };
}

let db: IDBPDatabase<WhoopDB>;

const deleteDB = async (name: string): Promise<void> => {
  return new Promise((resolve, reject) => {
    const request = window.indexedDB.deleteDatabase(name);
    request.onerror = () => reject(new Error('Could not delete database'));
    request.onsuccess = () => resolve();
  });
};

export const initDB = async () => {
  try {
    // Check if database already exists
    const existingDB = await openDB<WhoopDB>('whoop-sniper-db', 1);
    if (existingDB) {
      db = existingDB;
      return db;
    }
  } catch (error) {
    // Database doesn't exist or version is wrong, proceed with creation
    console.log('Creating new database...');
  }

  try {
    db = await openDB<WhoopDB>('whoop-sniper-db', 1, {
      upgrade(db) {
        // Create users store if it doesn't exist
        if (!db.objectStoreNames.contains('users')) {
          const userStore = db.createObjectStore('users', { keyPath: 'id' });
          userStore.createIndex('by-email', 'email', { unique: true });
          userStore.createIndex('by-role', 'role');
        }

        // Create bounties store if it doesn't exist
        if (!db.objectStoreNames.contains('bounties')) {
          const bountyStore = db.createObjectStore('bounties', { keyPath: 'id' });
          bountyStore.createIndex('by-status', 'status');
          bountyStore.createIndex('by-creator', 'createdBy');
        }
      },
    });

    // Initialize master user
    await ensureMasterExists();
    return db;
  } catch (error) {
    console.error('Error initializing database:', error);
    throw error;
  }
};

export const ensureMasterExists = async () => {
  try {
    const existingMaster = await getUserByEmail('master@whoopsniper.com');
    
    if (!existingMaster) {
      const masterUser: User = {
        id: 'master',
        username: 'Master Admin',
        email: 'master@whoopsniper.com',
        password: 'WhoopDoop2025#',
        role: 'master',
        status: 'happy',
        gems: 9999,
        completedBounties: [],
        createdBounties: [],
        createdAt: new Date().toISOString(),
      };
      
      await addUser(masterUser);
    }
  } catch (error) {
    if (error instanceof Error && error.name !== 'ConstraintError') {
      console.error('Error ensuring master exists:', error);
    }
  }
};

export const addUser = async (user: User) => {
  try {
    const existingUser = await getUserByEmail(user.email);
    if (existingUser) {
      return existingUser;
    }
    return await db.add('users', user);
  } catch (error) {
    if (error instanceof Error && error.name !== 'ConstraintError') {
      console.error('Error adding user:', error);
    }
    throw error;
  }
};

// Rest of the file remains unchanged
export const updateUser = async (user: User) => {
  try {
    const existingUser = await db.get('users', user.id);
    if (!existingUser) {
      throw new Error('User not found');
    }
    return await db.put('users', user);
  } catch (error) {
    console.error('Error updating user:', error);
    throw error;
  }
};

export const deleteUser = async (userId: string) => {
  try {
    const user = await db.get('users', userId);
    if (!user) {
      throw new Error('User not found');
    }
    if (user.role === 'master') {
      throw new Error('Cannot delete master user');
    }
    return await db.delete('users', userId);
  } catch (error) {
    console.error('Error deleting user:', error);
    throw error;
  }
};

export const getUserByEmail = async (email: string) => {
  try {
    return await db.getFromIndex('users', 'by-email', email);
  } catch (error) {
    console.error('Error getting user by email:', error);
    return null;
  }
};

export const getAllUsers = async () => {
  try {
    return await db.getAll('users');
  } catch (error) {
    console.error('Error getting all users:', error);
    return [];
  }
};

export const getUsersByRole = async (role: string) => {
  try {
    return await db.getAllFromIndex('users', 'by-role', role);
  } catch (error) {
    console.error('Error getting users by role:', error);
    return [];
  }
};

export const addBounty = async (bounty: Bounty) => {
  try {
    return await db.add('bounties', bounty);
  } catch (error) {
    console.error('Error adding bounty:', error);
    throw error;
  }
};

export const updateBounty = async (bounty: Bounty) => {
  try {
    return await db.put('bounties', bounty);
  } catch (error) {
    console.error('Error updating bounty:', error);
    throw error;
  }
};

export const deleteBounty = async (id: string) => {
  try {
    return await db.delete('bounties', id);
  } catch (error) {
    console.error('Error deleting bounty:', error);
    throw error;
  }
};

export const getBountyById = async (id: string) => {
  try {
    return await db.get('bounties', id);
  } catch (error) {
    console.error('Error getting bounty by id:', error);
    throw error;
  }
};

export const getBountiesByStatus = async (status: string) => {
  try {
    return await db.getAllFromIndex('bounties', 'by-status', status);
  } catch (error) {
    console.error('Error getting bounties by status:', error);
    return [];
  }
};

export const getBountiesByCreator = async (userId: string) => {
  try {
    return await db.getAllFromIndex('bounties', 'by-creator', userId);
  } catch (error) {
    console.error('Error getting bounties by creator:', error);
    return [];
  }
};