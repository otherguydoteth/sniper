import { createClient } from '@supabase/supabase-js';
import { User, Bounty } from '../types';
import { Database } from '../types/supabase';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey);

// User operations
export const syncUserToSupabase = async (user: User) => {
  const { data, error } = await supabase
    .from('users')
    .upsert({
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role,
      status: user.status,
      gems: user.gems,
      profile_image: user.profileImage,
      created_at: user.createdAt
    })
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const fetchUsersFromSupabase = async () => {
  const { data, error } = await supabase
    .from('users')
    .select('*');

  if (error) throw error;
  return data.map(user => ({
    id: user.id,
    username: user.username,
    email: user.email,
    role: user.role,
    status: user.status,
    gems: user.gems,
    profileImage: user.profile_image,
    completedBounties: [],
    createdAt: user.created_at
  }));
};

// Bounty operations
export const syncBountyToSupabase = async (bounty: Bounty) => {
  const { data, error } = await supabase
    .from('bounties')
    .upsert({
      id: bounty.id,
      name: bounty.name,
      description: bounty.description,
      image_url: bounty.imageUrl,
      marketplace_url: bounty.marketplaceUrl || null,
      prize_type: bounty.prizeType,
      prize_value: bounty.prizeValue,
      gem_reward: bounty.gemReward,
      status: bounty.status,
      winner_id: bounty.winner || null,
      created_by: bounty.createdBy,
      created_at: bounty.createdAt,
      completed_at: bounty.completedAt || null
    })
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const fetchBountiesFromSupabase = async () => {
  const { data, error } = await supabase
    .from('bounties')
    .select('*');

  if (error) throw error;
  return data.map(bounty => ({
    id: bounty.id,
    name: bounty.name,
    description: bounty.description,
    imageUrl: bounty.image_url,
    marketplaceUrl: bounty.marketplace_url || undefined,
    prizeType: bounty.prize_type,
    prizeValue: bounty.prize_value,
    gemReward: bounty.gem_reward,
    status: bounty.status,
    winner: bounty.winner_id || undefined,
    createdBy: bounty.created_by,
    createdAt: bounty.created_at,
    completedAt: bounty.completed_at || undefined
  }));
};

// Completed bounties operations
export const syncCompletedBountyToSupabase = async (userId: string, bountyId: string, gemsEarned: number) => {
  const { data, error } = await supabase
    .from('completed_bounties')
    .upsert({
      id: `${userId}_${bountyId}`,
      user_id: userId,
      bounty_id: bountyId,
      gems_earned: gemsEarned,
      completed_at: new Date().toISOString()
    })
    .select()
    .single();

  if (error) throw error;
  return data;
};