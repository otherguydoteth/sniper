import React from 'react';
import { AuthProvider } from './context/AuthContext';
import { LoginForm } from './components/Auth/LoginForm';
import { RegisterForm } from './components/Auth/RegisterForm';
import { BountyProvider } from './context/BountyContext';
import { BountyList } from './components/BountyList';
import { CompletedBounties } from './components/CompletedBounties';
import { UserProfile } from './components/UserProfile';
import { MasterAdminPanel } from './components/MasterAdminPanel';
import { useAuth } from './context/AuthContext';
import { Rocket, LogIn, X, Shield } from 'lucide-react';
import { AgentApplicationModal } from './components/AgentApplicationModal';

const AuthModal = ({ onClose }: { onClose: () => void }) => {
  const handleModalClick = (e: React.MouseEvent) => {
    e.stopPropagation();
  };

  return (
    <div 
      className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50"
      onClick={onClose}
    >
      <div 
        className="w-full max-w-md p-4"
        onClick={handleModalClick}
      >
        <div className="card p-6 relative">
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 text-secondary hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
          <div className="text-center mb-6">
            <Rocket className="w-12 h-12 text-primary mx-auto mb-4" />
            <h1 className="text-4xl font-bold text-white mb-2">Whoop Sniper</h1>
            <p className="text-secondary">Hunt NFTs. Earn Rewards. Build Your Collection.</p>
          </div>
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-white mb-4">Login</h2>
            <LoginForm />
          </div>
          <div className="border-t border-border pt-6">
            <h2 className="text-2xl font-bold text-white mb-4">Register</h2>
            <RegisterForm />
          </div>
        </div>
      </div>
    </div>
  );
};

const AppContent = () => {
  const { isAuthenticated, isMaster } = useAuth();
  const [showAuth, setShowAuth] = React.useState(false);
  const [showAgentApplication, setShowAgentApplication] = React.useState(false);

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-4">
        {isAuthenticated ? (
          <>
            <UserProfile />
            {isMaster && <MasterAdminPanel />}
            <div className="pt-24 space-y-12">
              <BountyList />
              <CompletedBounties />
            </div>
          </>
        ) : (
          <>
            <div className="py-8 text-center">
              <Rocket className="w-16 h-16 text-primary mx-auto mb-4" />
              <h1 className="text-4xl font-bold text-white mb-2">Whoop Sniper</h1>
              <p className="text-secondary">Hunt NFTs. Earn Rewards. Build Your Collection.</p>
            </div>
            <div className="space-y-12">
              <BountyList onSignInClick={() => setShowAuth(true)} />
              <CompletedBounties />
            </div>
            <div className="fixed bottom-8 right-8 flex gap-4">
              <button
                onClick={() => setShowAgentApplication(true)}
                className="btn-success flex items-center gap-2 shadow-lg"
              >
                <Shield className="w-5 h-5" />
                Agent
              </button>
              <button
                onClick={() => setShowAuth(true)}
                className="btn-primary flex items-center gap-2 shadow-lg"
              >
                <LogIn className="w-5 h-5" />
                Sign In
              </button>
            </div>
          </>
        )}
      </div>

      {showAuth && <AuthModal onClose={() => setShowAuth(false)} />}
      {showAgentApplication && (
        <AgentApplicationModal onClose={() => setShowAgentApplication(false)} />
      )}
    </div>
  );
};

function App() {
  return (
    <AuthProvider>
      <BountyProvider>
        <AppContent />
      </BountyProvider>
    </AuthProvider>
  );
}

export default App;