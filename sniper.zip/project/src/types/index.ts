export interface User {
  id: string;
  username: string;
  email: string;
  password: string;
  role: UserRole;
  status: UserStatus;
  gems: number;
  completedBounties: string[];
  createdBounties?: string[];
  profileImage?: string;
  createdAt: string;
}

export type UserRole = 'master' | 'admin' | 'agent' | 'user';
export type UserStatus = 'happy' | 'sad' | 'meh';
export type BountyStatus = 'active' | 'completed';
export type PrizeType = 'cash' | 'merchandise' | 'mystery-nft';

export interface Bounty {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  prizeType: PrizeType;
  prizeValue: string;
  status: BountyStatus;
  createdBy: string;
  winner?: string;
  createdAt: string;
  completedAt?: string;
}

export interface AuthState {
  user: User | null;
  users: User[];
  isAuthenticated: boolean;
  isAdmin: boolean;
  isAgent: boolean;
  isMaster: boolean;
}