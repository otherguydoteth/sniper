export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          username: string
          email: string
          role: 'master' | 'agent' | 'user'
          status: 'happy' | 'sad' | 'meh'
          gems: number
          profile_image: string | null
          created_at: string
        }
        Insert: {
          id?: string
          username: string
          email: string
          role?: 'master' | 'agent' | 'user'
          status?: 'happy' | 'sad' | 'meh'
          gems?: number
          profile_image?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          username?: string
          email?: string
          role?: 'master' | 'agent' | 'user'
          status?: 'happy' | 'sad' | 'meh'
          gems?: number
          profile_image?: string | null
          created_at?: string
        }
      }
      bounties: {
        Row: {
          id: string
          name: string
          description: string
          image_url: string
          marketplace_url: string | null
          prize_type: 'cash' | 'merchandise' | 'mystery'
          prize_value: string
          gem_reward: number
          status: 'active' | 'completed'
          winner_id: string | null
          created_by: string
          created_at: string
          completed_at: string | null
        }
        Insert: {
          id?: string
          name: string
          description: string
          image_url: string
          marketplace_url?: string | null
          prize_type: 'cash' | 'merchandise' | 'mystery'
          prize_value: string
          gem_reward: number
          status?: 'active' | 'completed'
          winner_id?: string | null
          created_by: string
          created_at?: string
          completed_at?: string | null
        }
        Update: {
          id?: string
          name?: string
          description?: string
          image_url?: string
          marketplace_url?: string | null
          prize_type?: 'cash' | 'merchandise' | 'mystery'
          prize_value?: string
          gem_reward?: number
          status?: 'active' | 'completed'
          winner_id?: string | null
          created_by?: string
          created_at?: string
          completed_at?: string | null
        }
      }
      completed_bounties: {
        Row: {
          id: string
          user_id: string
          bounty_id: string
          gems_earned: number
          completed_at: string
        }
        Insert: {
          id?: string
          user_id: string
          bounty_id: string
          gems_earned: number
          completed_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          bounty_id?: string
          gems_earned?: number
          completed_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}