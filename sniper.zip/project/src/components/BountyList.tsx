import React, { useState } from 'react';
import { useBounties } from '../hooks/useBounties';
import { BountyCard } from './BountyCard';
import { useAuth } from '../context/AuthContext';
import { BountyForm } from './admin/BountyForm';
import { Bounty } from '../types';

interface BountyListProps {
  onSignInClick?: () => void;
}

export const BountyList: React.FC<BountyListProps> = ({ onSignInClick }) => {
  const { activeBounties, editBounty } = useBounties();
  const [editingBounty, setEditingBounty] = useState<Bounty | null>(null);

  const handleEdit = (bounty: Bounty) => {
    setEditingBounty(bounty);
  };

  return (
    <section className="mb-16">
      <h2 className="text-3xl font-bold mb-8">Active Bounties</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {activeBounties.map((bounty) => (
          <div key={bounty.id} className="group">
            <BountyCard 
              bounty={bounty} 
              onEdit={handleEdit}
              onSignInClick={onSignInClick}
            />
          </div>
        ))}
      </div>

      {editingBounty && (
        <BountyForm
          bounty={editingBounty}
          onSubmit={(formData) => {
            editBounty(editingBounty.id, formData);
            setEditingBounty(null);
          }}
          onClose={() => setEditingBounty(null)}
        />
      )}
    </section>
  );
};