import React, { useState } from 'react';
import { X } from 'lucide-react';
import { User } from '../types';
import { useAuth } from '../context/AuthContext';

interface ProfileEditModalProps {
  user: User;
  onClose: () => void;
}

const StatusEmoji = {
  happy: { emoji: '😊', label: 'Happy' },
  sad: { emoji: '😢', label: 'Sad' },
  meh: { emoji: '😐', label: 'Meh' },
} as const;

export const ProfileEditModal: React.FC<ProfileEditModalProps> = ({ user, onClose }) => {
  const { updateProfile } = useAuth();
  const [formData, setFormData] = useState({
    username: user.username,
    profileImage: user.profileImage || '',
    status: user.status || 'meh',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateProfile(formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-card-bg border border-border rounded-xl w-full max-w-md p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Edit Profile</h2>
          <button onClick={onClose} className="text-secondary hover:text-white">
            <X className="w-6 h-6" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Username</label>
            <input
              type="text"
              value={formData.username}
              onChange={(e) => setFormData({ ...formData, username: e.target.value })}
              className="input w-full"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">Profile Image URL</label>
            <input
              type="url"
              value={formData.profileImage}
              onChange={(e) => setFormData({ ...formData, profileImage: e.target.value })}
              className="input w-full"
              placeholder="Enter image URL or leave empty for default avatar"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">Status</label>
            <div className="flex gap-4">
              {Object.entries(StatusEmoji).map(([value, { emoji, label }]) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setFormData({ ...formData, status: value as User['status'] })}
                  className={`flex-1 flex items-center justify-center gap-2 p-3 rounded-lg ${
                    formData.status === value
                      ? 'bg-primary text-white'
                      : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                  }`}
                >
                  <span className="text-xl">{emoji}</span>
                  <span>{label}</span>
                </button>
              ))}
            </div>
          </div>
          <div className="flex gap-4 pt-4">
            <button
              type="submit"
              className="flex-1 btn-primary"
            >
              Save Changes
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 btn-secondary"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};