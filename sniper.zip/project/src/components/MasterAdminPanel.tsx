import React, { useState } from 'react';
import { Users, Shield, Trash2, Search, UserPlus, Settings, SwitchCamera, ArrowLeftCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { User } from '../types';
import { UserEditModal } from './admin/UserEditModal';
import { AdminPanel } from './AdminPanel';

export const MasterAdminPanel = () => {
  const { user, users, promoteToAgent, demoteToUser, deleteUser, switchProfile, switchBackToMaster, masterUser } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [showCreateUser, setShowCreateUser] = useState(false);
  const [showUserManagement, setShowUserManagement] = useState(true);

  // Only render for master admin
  if (!user || user.role !== 'master') return null;

  const filteredUsers = users.filter(u => {
    const searchLower = searchTerm.toLowerCase();
    return (
      u.username.toLowerCase().includes(searchLower) ||
      u.email.toLowerCase().includes(searchLower) ||
      u.role.toLowerCase().includes(searchLower)
    );
  });

  const handlePromote = async (userId: string) => {
    try {
      await promoteToAgent(userId);
    } catch (error) {
      console.error('Failed to promote user:', error);
    }
  };

  const handleDemote = async (userId: string) => {
    try {
      await demoteToUser(userId);
    } catch (error) {
      console.error('Failed to demote agent:', error);
    }
  };

  const handleDelete = async (userId: string) => {
    if (window.confirm('Are you sure you want to delete this user?')) {
      try {
        await deleteUser(userId);
      } catch (error) {
        console.error('Failed to delete user:', error);
      }
    }
  };

  const handleSwitchProfile = (userToSwitch: User) => {
    if (userToSwitch.role !== 'master') {
      switchProfile(userToSwitch);
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'master':
        return 'bg-purple-500/10 text-purple-500';
      case 'agent':
        return 'bg-blue-500/10 text-blue-500';
      default:
        return 'bg-gray-500/10 text-gray-500';
    }
  };

  return (
    <>
      {/* Toggle between user management and bounty management */}
      <div className="fixed top-20 left-4 z-50">
        <div className="flex gap-2">
          <button
            onClick={() => setShowUserManagement(true)}
            className={`btn-primary ${showUserManagement ? 'bg-opacity-100' : 'bg-opacity-50'}`}
          >
            <Users className="w-4 h-4 mr-2" />
            Users
          </button>
          <button
            onClick={() => setShowUserManagement(false)}
            className={`btn-primary ${!showUserManagement ? 'bg-opacity-100' : 'bg-opacity-50'}`}
          >
            <Shield className="w-4 h-4 mr-2" />
            Bounties
          </button>
        </div>
      </div>

      {showUserManagement ? (
        <div className="fixed top-20 right-4 w-96 bg-card-bg rounded-lg shadow-xl p-4 space-y-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-xl font-bold">Master Admin Panel</h2>
              <p className="text-sm text-secondary mt-1">
                <Users className="w-4 h-4 inline mr-1" />
                {users.length} registered users
              </p>
            </div>
            <button
              onClick={() => setShowCreateUser(true)}
              className="btn-primary flex items-center gap-2"
              title="Create new user"
            >
              <UserPlus className="w-4 h-4" />
              <span className="hidden sm:inline">New User</span>
            </button>
          </div>

          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary w-4 h-4" />
            <input
              type="text"
              placeholder="Search users by name, email, or role..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="input pl-10 w-full"
            />
          </div>

          <div className="space-y-2 max-h-[calc(100vh-240px)] overflow-y-auto">
            {filteredUsers.map((userItem) => (
              <div 
                key={userItem.id}
                className="bg-hover-bg p-3 rounded-lg hover:bg-gray-800 transition-colors"
              >
                <div className="flex items-center gap-3 mb-2">
                  <img
                    src={userItem.profileImage || `https://api.dicebear.com/7.x/avatars/svg?seed=${userItem.username}`}
                    alt={userItem.username}
                    className="w-10 h-10 rounded-full"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium truncate">{userItem.username}</span>
                      <span className={`text-xs px-2 py-1 rounded-full ${getRoleColor(userItem.role)}`}>
                        {userItem.role}
                      </span>
                    </div>
                    <div className="text-sm text-secondary truncate">{userItem.email}</div>
                  </div>
                  <div className="flex gap-2">
                    {userItem.role !== 'master' && (
                      <button
                        onClick={() => handleSwitchProfile(userItem)}
                        className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
                        title="Switch to this profile"
                      >
                        <SwitchCamera className="w-4 h-4 text-secondary" />
                      </button>
                    )}
                    <button
                      onClick={() => setEditingUser(userItem)}
                      className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
                      title="Edit user"
                    >
                      <Settings className="w-4 h-4 text-secondary" />
                    </button>
                  </div>
                </div>

                {userItem.role !== 'master' && (
                  <div className="flex gap-2 mt-2">
                    {userItem.role === 'user' ? (
                      <button
                        onClick={() => handlePromote(userItem.id)}
                        className="flex-1 btn-primary flex items-center justify-center gap-2 text-sm"
                      >
                        <Shield className="w-4 h-4" />
                        Make Agent
                      </button>
                    ) : (
                      <button
                        onClick={() => handleDemote(userItem.id)}
                        className="flex-1 btn-secondary flex items-center justify-center gap-2 text-sm"
                      >
                        <Shield className="w-4 h-4" />
                        Remove Agent
                      </button>
                    )}
                    <button
                      onClick={() => handleDelete(userItem.id)}
                      className="btn-danger px-3"
                      title="Delete user"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      ) : (
        // Show AdminPanel with master privileges
        <AdminPanel />
      )}

      {/* Show switch back button when viewing as another user */}
      {masterUser && user.id !== masterUser.id && (
        <button
          onClick={switchBackToMaster}
          className="fixed bottom-8 left-8 btn-primary flex items-center gap-2"
        >
          <ArrowLeftCircle className="w-4 h-4" />
          Back to Master
        </button>
      )}

      {(editingUser || showCreateUser) && (
        <UserEditModal
          user={editingUser}
          onClose={() => {
            setEditingUser(null);
            setShowCreateUser(false);
          }}
        />
      )}
    </>
  );
};