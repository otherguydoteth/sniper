import React, { useState } from 'react';
import { X, Send } from 'lucide-react';

interface AgentApplicationModalProps {
  onClose: () => void;
}

export const AgentApplicationModal: React.FC<AgentApplicationModalProps> = ({ onClose }) => {
  const [formData, setFormData] = useState({
    name: '',
    projectName: '',
    xProfile: '',
    email: '',
    discord: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Send email using mailto link
      const subject = encodeURIComponent('New Agent Application - Whoop Sniper');
      const body = encodeURIComponent(`
Name: ${formData.name}
Project Name: ${formData.projectName}
X Profile: ${formData.xProfile}
Contact Email: ${formData.email}
Discord: ${formData.discord}
      `);
      
      window.location.href = `mailto:alexander.stru@gmail.com?subject=${subject}&body=${body}`;
      setSubmitted(true);
    } catch (error) {
      console.error('Error submitting application:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleModalClick = (e: React.MouseEvent) => {
    e.stopPropagation();
  };

  return (
    <div 
      className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50"
      onClick={onClose}
    >
      <div 
        className="w-full max-w-md p-4"
        onClick={handleModalClick}
      >
        <div className="card p-6 relative">
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 text-secondary hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>

          {submitted ? (
            <div className="text-center py-8">
              <h2 className="text-2xl font-bold mb-4">Application Sent!</h2>
              <p className="text-secondary mb-6">
                Thank you for your interest in becoming a bounty setter. We'll review your application and get back to you soon.
              </p>
              <button
                onClick={onClose}
                className="btn-primary"
              >
                Close
              </button>
            </div>
          ) : (
            <>
              <div className="text-center mb-6">
                <h2 className="text-2xl font-bold">Apply to be Bounty Setter</h2>
                <p className="text-secondary">Join our network of NFT bounty creators</p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Name</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="input w-full"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Project Name</label>
                  <input
                    type="text"
                    value={formData.projectName}
                    onChange={(e) => setFormData({ ...formData, projectName: e.target.value })}
                    className="input w-full"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">X Profile</label>
                  <input
                    type="text"
                    value={formData.xProfile}
                    onChange={(e) => setFormData({ ...formData, xProfile: e.target.value })}
                    className="input w-full"
                    placeholder="@username"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Contact Email</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="input w-full"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Discord</label>
                  <input
                    type="text"
                    value={formData.discord}
                    onChange={(e) => setFormData({ ...formData, discord: e.target.value })}
                    className="input w-full"
                    placeholder="username#0000"
                    required
                  />
                </div>

                <div className="flex gap-4 pt-4">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="flex-1 btn-success flex items-center justify-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    {isSubmitting ? 'Sending...' : 'Submit Application'}
                  </button>
                  <button
                    type="button"
                    onClick={onClose}
                    className="flex-1 btn-secondary"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
};