import React, { useState } from 'react';
import { X, Search, Gem } from 'lucide-react';
import { User } from '../../types';
import { useAuth } from '../../context/AuthContext';

interface GemAwardModalProps {
  onAward: (userId: string, amount: number) => void;
  onClose: () => void;
}

export const GemAwardModal: React.FC<GemAwardModalProps> = ({
  onAward,
  onClose,
}) => {
  const { users } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [gemAmount, setGemAmount] = useState<number>(0);

  const filteredUsers = users.filter(user => 
    user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedUser && gemAmount > 0) {
      onAward(selectedUser.id, gemAmount);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-card-bg border border-border rounded-xl w-full max-w-md p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Award Gems</h2>
          <button onClick={onClose} className="text-secondary hover:text-white">
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary w-4 h-4" />
            <input
              type="text"
              placeholder="Search users..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="input pl-10 w-full"
            />
          </div>

          <div className="max-h-[200px] overflow-y-auto space-y-2">
            {filteredUsers.map((user) => (
              <button
                key={user.id}
                type="button"
                onClick={() => setSelectedUser(user)}
                className={`w-full flex items-center gap-3 p-3 rounded-lg transition-colors ${
                  selectedUser?.id === user.id
                    ? 'bg-primary/10 border border-primary'
                    : 'hover:bg-hover-bg'
                }`}
              >
                <img
                  src={user.profileImage || `https://api.dicebear.com/7.x/avatars/svg?seed=${user.username}`}
                  alt={user.username}
                  className="w-10 h-10 rounded-full"
                />
                <div className="flex-1 text-left">
                  <div className="font-medium">{user.username}</div>
                  <div className="text-secondary text-sm">{user.email}</div>
                </div>
                <div className="flex items-center gap-1 text-primary">
                  <Gem className="w-4 h-4" />
                  <span>{user.gems}</span>
                </div>
              </button>
            ))}
          </div>

          {selectedUser && (
            <div className="space-y-4 pt-4 border-t border-border">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Gems to Award
                </label>
                <input
                  type="number"
                  min="1"
                  value={gemAmount}
                  onChange={(e) => setGemAmount(parseInt(e.target.value) || 0)}
                  className="input w-full"
                  required
                />
              </div>

              <div className="flex gap-4">
                <button
                  type="submit"
                  disabled={!selectedUser || gemAmount <= 0}
                  className="flex-1 btn-primary disabled:opacity-50"
                >
                  Award Gems
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 btn-secondary"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}
        </form>
      </div>
    </div>
  );
};