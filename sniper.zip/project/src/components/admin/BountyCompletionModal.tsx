import React, { useState } from 'react';
import { X, Search, CheckCircle } from 'lucide-react';
import { User, Bounty } from '../../types';
import { useAuth } from '../../context/AuthContext';

interface BountyCompletionModalProps {
  bounty: Bounty;
  onComplete: (userId: string) => void;
  onClose: () => void;
}

export const BountyCompletionModal: React.FC<BountyCompletionModalProps> = ({
  bounty,
  onComplete,
  onClose,
}) => {
  const { users } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');

  const filteredUsers = users.filter(user => 
    user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-card-bg border border-border rounded-xl w-full max-w-md p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Complete Bounty</h2>
          <button onClick={onClose} className="text-secondary hover:text-white">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="mb-6">
          <h3 className="font-semibold mb-2">Bounty: {bounty.name}</h3>
          <p className="text-secondary text-sm">Select the user who completed this bounty</p>
        </div>

        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary w-4 h-4" />
          <input
            type="text"
            placeholder="Search users..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="input pl-10 w-full"
          />
        </div>

        <div className="max-h-[300px] overflow-y-auto space-y-2">
          {filteredUsers.map((user) => (
            <button
              key={user.id}
              onClick={() => onComplete(user.id)}
              className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-hover-bg transition-colors"
            >
              <img
                src={user.profileImage || `https://api.dicebear.com/7.x/avatars/svg?seed=${user.username}`}
                alt={user.username}
                className="w-10 h-10 rounded-full"
              />
              <div className="flex-1 text-left">
                <div className="font-medium">{user.username}</div>
                <div className="text-secondary text-sm">{user.email}</div>
              </div>
              <CheckCircle className="w-5 h-5 text-primary opacity-0 group-hover:opacity-100" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};