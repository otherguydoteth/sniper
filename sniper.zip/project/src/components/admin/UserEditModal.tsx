import React, { useState } from 'react';
import { X, AlertCircle } from 'lucide-react';
import { User, UserRole } from '../../types';
import { useAuth } from '../../context/AuthContext';

interface UserEditModalProps {
  user: User | null; // null means creating new user
  onClose: () => void;
}

const StatusEmoji = {
  happy: { emoji: '😊', label: 'Happy' },
  sad: { emoji: '😢', label: 'Sad' },
  meh: { emoji: '😐', label: 'Meh' },
} as const;

export const UserEditModal: React.FC<UserEditModalProps> = ({ user, onClose }) => {
  const { updateProfile, register } = useAuth();
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    username: user?.username || '',
    email: user?.email || '',
    password: '',
    role: user?.role || 'user' as UserRole,
    status: user?.status || 'meh',
    gems: user?.gems || 0,
    profileImage: user?.profileImage || '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    try {
      if (user) {
        // Update existing user
        await updateProfile({
          ...user,
          ...formData,
        });
      } else {
        // Create new user
        await register(formData.username, formData.email, formData.password);
      }
      onClose();
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Operation failed');
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-card-bg border border-border rounded-xl w-full max-w-md p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">
            {user ? 'Edit User' : 'Create User'}
          </h2>
          <button onClick={onClose} className="text-secondary hover:text-white">
            <X className="w-6 h-6" />
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-500 bg-opacity-20 border border-red-500 rounded-lg text-red-500 flex items-center gap-2">
            <AlertCircle className="w-4 h-4" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Username</label>
            <input
              type="text"
              value={formData.username}
              onChange={(e) => setFormData({ ...formData, username: e.target.value })}
              className="input w-full"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Email</label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="input w-full"
              required
            />
          </div>

          {!user && (
            <div>
              <label className="block text-sm font-medium mb-2">Password</label>
              <input
                type="password"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className="input w-full"
                required
              />
            </div>
          )}

          <div>
            <label className="block text-sm font-medium mb-2">Role</label>
            <select
              value={formData.role}
              onChange={(e) => setFormData({ ...formData, role: e.target.value as UserRole })}
              className="input w-full"
              required
            >
              <option value="user">User</option>
              <option value="agent">Agent</option>
              {!user && <option value="master">Master</option>}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Status</label>
            <div className="flex gap-4">
              {Object.entries(StatusEmoji).map(([value, { emoji, label }]) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setFormData({ ...formData, status: value as User['status'] })}
                  className={`flex-1 flex items-center justify-center gap-2 p-3 rounded-lg transition-colors ${
                    formData.status === value
                      ? 'bg-primary text-white'
                      : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                  }`}
                >
                  <span className="text-xl">{emoji}</span>
                  <span>{label}</span>
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Gems</label>
            <input
              type="number"
              value={formData.gems}
              onChange={(e) => setFormData({ ...formData, gems: parseInt(e.target.value) || 0 })}
              className="input w-full"
              min="0"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Profile Image URL</label>
            <input
              type="url"
              value={formData.profileImage}
              onChange={(e) => setFormData({ ...formData, profileImage: e.target.value })}
              className="input w-full"
              placeholder="Enter image URL or leave empty for default avatar"
            />
          </div>

          <div className="flex gap-4 pt-4">
            <button
              type="submit"
              className="flex-1 btn-primary"
            >
              {user ? 'Update User' : 'Create User'}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 btn-secondary"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};