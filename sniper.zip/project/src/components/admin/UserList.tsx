import React, { useState } from 'react';
import { User } from '../../types';
import { X, Gem, Pencil, Shield } from 'lucide-react';
import { ProfileEditModal } from '../ProfileEditModal';
import { useAuth } from '../../context/AuthContext';

interface UserListProps {
  users: User[];
  onClose: () => void;
  onSelectUser: (user: User) => void;
}

const StatusEmoji = {
  happy: '😊',
  sad: '😢',
  meh: '😐',
} as const;

export const UserList: React.FC<UserListProps> = ({ users, onClose, onSelectUser }) => {
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const { user: currentUser, promoteToAgent } = useAuth();

  const handlePromoteToAgent = async (userId: string) => {
    try {
      await promoteToAgent(userId);
    } catch (error) {
      console.error('Failed to promote user:', error);
    }
  };

  return (
    <>
      <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
        <div className="bg-card-bg border border-border rounded-xl w-full max-w-md p-6 max-h-[80vh] overflow-y-auto">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">Registered Users</h2>
            <button onClick={onClose} className="text-secondary hover:text-white">
              <X className="w-6 h-6" />
            </button>
          </div>
          <div className="space-y-4">
            {users.map((user) => (
              <div
                key={user.id}
                className="flex items-center gap-4 p-4 bg-hover-bg rounded-lg hover:bg-gray-800 transition-colors"
              >
                <img
                  src={user.profileImage || `https://api.dicebear.com/7.x/avatars/svg?seed=${user.username}`}
                  alt={user.username}
                  className="w-12 h-12 rounded-full"
                />
                <div className="flex-grow">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold">{user.username}</h3>
                    <span className="text-xl" role="img" aria-label={user.status}>
                      {StatusEmoji[user.status || 'meh']}
                    </span>
                    <span className="text-xs px-2 py-1 rounded-full bg-primary/10 text-primary">
                      {user.role}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-primary">
                    <Gem className="w-4 h-4" />
                    <span>{user.gems} gems</span>
                  </div>
                </div>
                {currentUser?.role === 'admin' && (
                  <div className="flex gap-2">
                    <button
                      onClick={() => setEditingUser(user)}
                      className="p-2 bg-blue-500 hover:bg-blue-600 rounded-lg transition-colors"
                      title="Edit user"
                    >
                      <Pencil className="w-4 h-4" />
                    </button>
                    {user.role === 'user' && (
                      <button
                        onClick={() => handlePromoteToAgent(user.id)}
                        className="p-2 bg-green-500 hover:bg-green-600 rounded-lg transition-colors"
                        title="Promote to Agent"
                      >
                        <Shield className="w-4 h-4" />
                      </button>
                    )}
                    <button
                      onClick={() => onSelectUser(user)}
                      className="p-2 bg-primary hover:bg-primary/90 rounded-lg transition-colors"
                      title="Select user"
                    >
                      Select
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {editingUser && currentUser?.role === 'admin' && (
        <ProfileEditModal
          user={editingUser}
          onClose={() => setEditingUser(null)}
        />
      )}
    </>
  );
};