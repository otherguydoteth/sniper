import React, { useState, useEffect } from 'react';
import { X, AlertCircle, Link } from 'lucide-react';
import { Bounty, User } from '../../types';
import { useAuth } from '../../context/AuthContext';

interface BountyFormProps {
  bounty?: Bounty | null;
  onSubmit: (formData: Omit<Bounty, 'id' | 'createdBy'>) => void;
  onClose: () => void;
}

export const BountyForm: React.FC<BountyFormProps> = ({ bounty, onSubmit, onClose }) => {
  const { user, users } = useAuth();
  const [error, setError] = useState<string>('');
  const [showUserSelect, setShowUserSelect] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    imageUrl: '',
    marketplaceUrl: '',
    prizeType: 'cash' as Bounty['prizeType'],
    prizeValue: '',
    gemReward: 0,
    status: 'active' as 'active' | 'completed',
    winner: '',
    completedAt: '',
  });

  useEffect(() => {
    if (bounty) {
      if (user?.role !== 'admin' && bounty.createdBy !== user?.id) {
        setError('You can only edit your own bounties');
        return;
      }

      setFormData({
        name: bounty.name,
        description: bounty.description,
        imageUrl: bounty.imageUrl,
        marketplaceUrl: bounty.marketplaceUrl || '',
        prizeType: bounty.prizeType,
        prizeValue: bounty.prizeValue,
        gemReward: bounty.gemReward,
        status: bounty.status || 'active',
        winner: bounty.winner || '',
        completedAt: bounty.completedAt || '',
      });
      setShowUserSelect(bounty.status === 'completed');
    }
  }, [bounty, user]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !['admin', 'agent'].includes(user.role)) {
      setError('Only admins and agents can manage bounties');
      return;
    }

    if (formData.status === 'completed' && !formData.winner) {
      setError('Please select a user who completed this bounty');
      return;
    }

    onSubmit(formData);
  };

  const handleStatusChange = (status: 'active' | 'completed') => {
    setFormData({ ...formData, status });
    setShowUserSelect(status === 'completed');
    if (status === 'active') {
      setFormData(prev => ({ ...prev, winner: '', completedAt: '' }));
    }
  };

  if (!user || !['admin', 'agent'].includes(user.role)) {
    return null;
  }

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-card-bg border border-border rounded-xl w-full max-w-md p-6 max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">
            {bounty ? 'Edit Bounty' : 'Create Bounty'}
          </h2>
          <button onClick={onClose} className="text-secondary hover:text-white">
            <X className="w-6 h-6" />
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-500 bg-opacity-20 border border-red-500 rounded-lg text-red-500 flex items-center gap-2">
            <AlertCircle className="w-4 h-4" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="text"
            placeholder="Bounty Name"
            value={formData.name}
            onChange={(e) => setFormData({...formData, name: e.target.value})}
            className="input w-full"
            required
          />
          <textarea
            placeholder="Description"
            value={formData.description}
            onChange={(e) => setFormData({...formData, description: e.target.value})}
            className="input w-full min-h-[100px]"
            required
          />
          <input
            type="url"
            placeholder="Image URL"
            value={formData.imageUrl}
            onChange={(e) => setFormData({...formData, imageUrl: e.target.value})}
            className="input w-full"
            required
          />
          <div className="relative">
            <Link className="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary w-4 h-4" />
            <input
              type="url"
              placeholder="Marketplace URL"
              value={formData.marketplaceUrl}
              onChange={(e) => setFormData({...formData, marketplaceUrl: e.target.value})}
              className="input w-full pl-10"
            />
          </div>
          <select
            value={formData.prizeType}
            onChange={(e) => setFormData({...formData, prizeType: e.target.value as Bounty['prizeType']})}
            className="input w-full"
            required
          >
            <option value="cash">Cash</option>
            <option value="merchandise">Merchandise</option>
            <option value="mystery">Mystery NFT</option>
          </select>
          <input
            type="text"
            placeholder="Prize Value"
            value={formData.prizeValue}
            onChange={(e) => setFormData({...formData, prizeValue: e.target.value})}
            className="input w-full"
            required
          />
          <input
            type="number"
            placeholder="Gem Reward"
            value={formData.gemReward}
            onChange={(e) => setFormData({...formData, gemReward: parseInt(e.target.value)})}
            className="input w-full"
            required
          />
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => handleStatusChange('active')}
              className={`flex-1 py-2 px-4 rounded-full transition-colors ${
                formData.status === 'active'
                  ? 'bg-primary text-white'
                  : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
              }`}
            >
              Active
            </button>
            <button
              type="button"
              onClick={() => handleStatusChange('completed')}
              className={`flex-1 py-2 px-4 rounded-full transition-colors ${
                formData.status === 'completed'
                  ? 'bg-primary text-white'
                  : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
              }`}
            >
              Completed
            </button>
          </div>

          {showUserSelect && (
            <select
              value={formData.winner}
              onChange={(e) => setFormData({
                ...formData,
                winner: e.target.value,
                completedAt: e.target.value ? new Date().toISOString() : ''
              })}
              className="input w-full"
              required
            >
              <option value="">Select User Who Completed</option>
              {users.map(user => (
                <option key={user.id} value={user.username}>
                  {user.username}
                </option>
              ))}
            </select>
          )}

          <div className="flex gap-4 pt-4">
            <button
              type="submit"
              className="flex-1 btn-primary"
            >
              {bounty ? 'Update Bounty' : 'Create Bounty'}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 btn-secondary"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};