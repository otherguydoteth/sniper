import React from 'react';
import { AdminPanel } from './AdminPanel';
import { useAdmin } from '../hooks/useAdmin';

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAdmin } = useAdmin();

  return (
    <div>
      {isAdmin && <AdminPanel />}
      {children}
    </div>
  );
}