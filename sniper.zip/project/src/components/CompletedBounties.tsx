import React from 'react';
import { Trophy, Trash2, Edit2 } from 'lucide-react';
import { useBounties } from '../hooks/useBounties';
import { useAuth } from '../context/AuthContext';
import { BountyForm } from './admin/BountyForm';
import { Bounty } from '../types';

export const CompletedBounties = () => {
  const { completedBounties, removeCompletedBounty, editBounty } = useBounties();
  const { user } = useAuth();
  const [editingBounty, setEditingBounty] = React.useState<Bounty | null>(null);

  const canManage = (bountyCreatorId: string) => {
    return user?.role === 'master' || (user?.role === 'agent' && bountyCreatorId === user?.id);
  };

  return (
    <section className="mb-16">
      <h2 className="text-3xl font-bold mb-8">Whoop of Fame</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {completedBounties.map((bounty) => (
          <div 
            key={bounty.id}
            className="bg-[#1c1d21] rounded-lg overflow-hidden relative group"
          >
            <div className="relative">
              <img 
                src={bounty.imageUrl} 
                alt={bounty.name}
                className="w-full aspect-square object-cover"
              />
              <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                <div className="text-3xl font-bold text-white transform -rotate-45 border-4 border-white px-4 py-2 rounded">
                  WHOOPED
                </div>
              </div>
              {canManage(bounty.createdBy) && (
                <div className="absolute top-2 right-2 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={() => setEditingBounty(bounty)}
                    className="bg-blue-500 hover:bg-blue-600 p-2 rounded-lg transition-colors"
                    title="Edit bounty"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => removeCompletedBounty(bounty.id)}
                    className="bg-red-500 hover:bg-red-600 p-2 rounded-lg transition-colors"
                    title="Remove from Whoop of Fame"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
            <div className="p-6">
              <h3 className="text-xl font-bold mb-2">{bounty.name}</h3>
              <div className="flex items-center gap-2 text-purple-400 mb-2">
                <Trophy size={16} />
                <span>Whooped by: {bounty.winner}</span>
              </div>
              <div className="text-gray-400 text-sm">
                Whooped on: {new Date(bounty.completedAt!).toLocaleDateString()}
              </div>
              <div className="mt-2 text-purple-400">
                Gems Awarded: {bounty.gemReward}
              </div>
            </div>
          </div>
        ))}
      </div>

      {editingBounty && (
        <BountyForm
          bounty={editingBounty}
          onSubmit={(formData) => {
            editBounty(editingBounty.id, formData);
            setEditingBounty(null);
          }}
          onClose={() => setEditingBounty(null)}
        />
      )}
    </section>
  );
};