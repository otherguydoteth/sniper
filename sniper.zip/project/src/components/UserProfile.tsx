import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Gem, Pencil, LogOut, Plus, Trophy, ArrowLeftCircle } from 'lucide-react';
import { ProfileEditModal } from './ProfileEditModal';
import { BountyForm } from './admin/BountyForm';
import { useBounties } from '../hooks/useBounties';

const StatusEmoji = {
  happy: '😊',
  sad: '😢',
  meh: '😐',
} as const;

export const UserProfile = () => {
  const { user, logout, masterUser, switchBackToMaster } = useAuth();
  const { addBounty, completedBounties } = useBounties();
  const [isEditing, setIsEditing] = useState(false);
  const [isCreatingBounty, setIsCreatingBounty] = useState(false);
  const [showCompletedBounties, setShowCompletedBounties] = useState(false);

  if (!user) return null;

  const isAdminOrAgent = user.role === 'admin' || user.role === 'agent';
  const isSwitchedProfile = masterUser && user.id !== masterUser.id;

  // Calculate total gems (base gems + bounty rewards)
  const userCompletedBounties = completedBounties.filter(bounty => bounty.winner === user.username);
  const bountyGems = userCompletedBounties.reduce((total, bounty) => total + bounty.gemReward, 0);
  const totalGems = user.gems + bountyGems;

  return (
    <>
      <div className="fixed top-0 left-0 right-0 bg-background/80 backdrop-blur-sm border-b border-border z-40">
        <div className="max-w-6xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="relative group">
                <img
                  src={user.profileImage || `https://api.dicebear.com/7.x/avatars/svg?seed=${user.username}`}
                  alt={user.username}
                  className="w-10 h-10 rounded-full border border-border"
                />
                <button
                  onClick={() => setIsEditing(true)}
                  className="absolute -top-1 -right-1 bg-primary hover:bg-primary/90 p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <Pencil className="w-3 h-3" />
                </button>
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-white">{user.username}</h3>
                  <span className="text-xl" role="img" aria-label={user.status}>
                    {StatusEmoji[user.status || 'meh']}
                  </span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1.5 text-primary text-sm">
                    <Gem className="w-4 h-4" />
                    <span>{totalGems} gems</span>
                  </div>
                  <button
                    onClick={() => setShowCompletedBounties(!showCompletedBounties)}
                    className="flex items-center gap-1.5 text-secondary hover:text-primary text-sm transition-colors"
                  >
                    <Trophy className="w-4 h-4" />
                    <span>{userCompletedBounties.length} completed</span>
                  </button>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {isSwitchedProfile && (
                <button
                  onClick={switchBackToMaster}
                  className="btn-secondary flex items-center gap-2"
                >
                  <ArrowLeftCircle className="w-4 h-4" />
                  <span className="hidden sm:inline">Back to Master</span>
                </button>
              )}
              {isAdminOrAgent && (
                <button
                  onClick={() => setIsCreatingBounty(true)}
                  className="btn-primary flex items-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  <span className="hidden sm:inline">Create Bounty</span>
                </button>
              )}
              <button
                onClick={logout}
                className="btn-danger flex items-center gap-2"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline">Logout</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Completed Bounties Dropdown */}
      {showCompletedBounties && userCompletedBounties.length > 0 && (
        <div className="fixed top-16 left-4 w-80 bg-card-bg border border-border rounded-xl shadow-xl z-30">
          <div className="p-4">
            <h3 className="font-bold mb-4">Completed Bounties</h3>
            <div className="space-y-3 max-h-[300px] overflow-y-auto">
              {userCompletedBounties.map((bounty) => (
                <div
                  key={bounty.id}
                  className="flex items-center gap-3 p-3 bg-hover-bg rounded-lg"
                >
                  <img
                    src={bounty.imageUrl}
                    alt={bounty.name}
                    className="w-12 h-12 rounded object-cover"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-sm truncate">{bounty.name}</h4>
                    <div className="flex items-center gap-2 text-xs text-secondary">
                      <Gem className="w-3 h-3 text-primary" />
                      <span>{bounty.gemReward} gems</span>
                      <span>•</span>
                      <span>{new Date(bounty.completedAt!).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {isEditing && (
        <ProfileEditModal
          user={user}
          onClose={() => setIsEditing(false)}
        />
      )}

      {isCreatingBounty && (
        <BountyForm
          onSubmit={(formData) => {
            addBounty(formData);
            setIsCreatingBounty(false);
          }}
          onClose={() => setIsCreatingBounty(false)}
        />
      )}
    </>
  );
};