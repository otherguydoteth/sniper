import React, { useState } from 'react';
import { Plus, Edit2, Trash2, Award, Users, CheckCircle, Search } from 'lucide-react';
import { useBounties } from '../hooks/useBounties';
import { useAuth } from '../context/AuthContext';
import { Bounty } from '../types';
import { UserList } from './admin/UserList';
import { BountyForm } from './admin/BountyForm';
import { BountyCompletionModal } from './admin/BountyCompletionModal';
import { GemAwardModal } from './admin/GemAwardModal';

export const AdminPanel = () => {
  const { user } = useAuth();
  const { addBounty, editBounty, removeBounty, awardGems, activeBounties, markBountyCompleted } = useBounties();
  const { users } = useAuth();
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [showUsers, setShowUsers] = useState(false);
  const [showGemAward, setShowGemAward] = useState(false);
  const [editingBounty, setEditingBounty] = useState<Bounty | null>(null);
  const [completingBounty, setCompletingBounty] = useState<Bounty | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  // Only render if user is admin or agent
  if (!user || !['admin', 'agent'].includes(user.role)) return null;

  const filteredBounties = activeBounties.filter(bounty => {
    const searchLower = searchTerm.toLowerCase();
    return (
      bounty.name.toLowerCase().includes(searchLower) ||
      bounty.description.toLowerCase().includes(searchLower) ||
      bounty.prizeType.toLowerCase().includes(searchLower)
    );
  });

  const handleMarkCompleted = async (userId: string) => {
    if (completingBounty) {
      await markBountyCompleted(completingBounty.id, userId);
      setCompletingBounty(null);
    }
  };

  const handleAwardGems = async (userId: string, amount: number) => {
    await awardGems(userId, amount);
    setShowGemAward(false);
  };

  const canManageBounty = (bounty: Bounty) => {
    return user.role === 'admin' || bounty.createdBy === user.id;
  };

  return (
    <>
      {/* Fixed Admin Controls */}
      <div className="fixed bottom-8 right-8 z-50 flex flex-col gap-4">
        {user.role === 'admin' && (
          <>
            <button
              onClick={() => setShowGemAward(true)}
              className="bg-purple-600 hover:bg-purple-700 text-white p-4 rounded-full shadow-lg transition-colors"
              title="Award Gems"
            >
              <Award className="w-6 h-6" />
            </button>
            <button
              onClick={() => setShowUsers(!showUsers)}
              className="bg-blue-600 hover:bg-blue-700 text-white p-4 rounded-full shadow-lg transition-colors"
              title="Manage Users"
            >
              <Users className="w-6 h-6" />
            </button>
          </>
        )}
        <button
          onClick={() => {
            setEditingBounty(null);
            setIsFormOpen(true);
          }}
          className="bg-green-500 hover:bg-green-600 text-white p-4 rounded-full shadow-lg transition-colors"
          title="Create New Bounty"
        >
          <Plus className="w-6 h-6" />
        </button>
      </div>

      {/* Bounty Management Panel */}
      <div className="fixed top-20 right-4 w-80 bg-card-bg rounded-lg shadow-xl p-4 space-y-4">
        <h2 className="text-xl font-bold mb-4">Bounty Management</h2>
        
        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary w-4 h-4" />
          <input
            type="text"
            placeholder="Search bounties..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="input pl-10 w-full"
          />
        </div>

        {/* Bounty List */}
        <div className="space-y-2 max-h-[60vh] overflow-y-auto">
          {filteredBounties.map((bounty) => (
            <div 
              key={bounty.id} 
              className="flex flex-col gap-2 bg-hover-bg p-3 rounded-lg hover:bg-gray-800 transition-colors"
            >
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <h3 className="font-semibold text-sm">{bounty.name}</h3>
                  <span className="text-xs text-primary">{bounty.prizeType} - {bounty.prizeValue}</span>
                </div>
                <span className="text-xs text-secondary">
                  {bounty.createdBy === user.id ? 'Your bounty' : ''}
                </span>
              </div>
              
              {canManageBounty(bounty) && (
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      setEditingBounty(bounty);
                      setIsFormOpen(true);
                    }}
                    className="flex-1 bg-blue-500 hover:bg-blue-600 p-2 rounded-lg text-sm transition-colors"
                    title="Edit bounty"
                  >
                    <Edit2 className="w-4 h-4 inline mr-1" />
                    Edit
                  </button>
                  <button
                    onClick={() => removeBounty(bounty.id)}
                    className="bg-red-500 hover:bg-red-600 p-2 rounded-lg transition-colors"
                    title="Remove bounty"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setCompletingBounty(bounty)}
                    className="bg-green-500 hover:bg-green-600 p-2 rounded-lg transition-colors"
                    title="Mark completed"
                  >
                    <CheckCircle className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Modals */}
      {showUsers && (
        <UserList
          users={users}
          onClose={() => setShowUsers(false)}
          onSelectUser={() => {}}
        />
      )}

      {isFormOpen && (
        <BountyForm
          bounty={editingBounty}
          onSubmit={(formData) => {
            if (editingBounty) {
              editBounty(editingBounty.id, formData);
            } else {
              addBounty(formData);
            }
            setIsFormOpen(false);
            setEditingBounty(null);
          }}
          onClose={() => {
            setIsFormOpen(false);
            setEditingBounty(null);
          }}
        />
      )}

      {completingBounty && (
        <BountyCompletionModal
          bounty={completingBounty}
          onComplete={handleMarkCompleted}
          onClose={() => setCompletingBounty(null)}
        />
      )}

      {showGemAward && (
        <GemAwardModal
          onAward={handleAwardGems}
          onClose={() => setShowGemAward(false)}
        />
      )}
    </>
  );
};