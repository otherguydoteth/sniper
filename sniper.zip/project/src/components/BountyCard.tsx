import React from 'react';
import { Share2, Edit2, Trash2, ExternalLink, LogIn } from 'lucide-react';
import { Bounty } from '../types';
import { useAuth } from '../context/AuthContext';
import { useBounties } from '../hooks/useBounties';

interface BountyCardProps {
  bounty: Bounty;
  onEdit?: (bounty: Bounty) => void;
  onSignInClick?: () => void;
}

export const BountyCard: React.FC<BountyCardProps> = ({ bounty, onEdit, onSignInClick }) => {
  const { user } = useAuth();
  const { removeBounty } = useBounties();

  const canManageBounty = user && (
    user.role === 'master' || 
    (user.role === 'agent' && bounty.createdBy === user.id)
  );

  const handleShare = () => {
    const text = `I'm going after this bounty - wish me luck! 🎯\n\n${bounty.name}\n`;
    const url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="card overflow-hidden group">
      <div className="relative aspect-square">
        <img 
          src={bounty.imageUrl} 
          alt={bounty.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-3 right-3 bg-primary/90 backdrop-blur-sm text-white px-3 py-1 rounded-full text-sm">
          {bounty.prizeType}
        </div>
        
        {canManageBounty && (
          <div className="absolute top-3 left-3 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <button
              onClick={() => onEdit?.(bounty)}
              className="bg-gray-900/90 hover:bg-gray-800/90 backdrop-blur-sm p-2 rounded-full transition-colors"
              title="Edit bounty"
            >
              <Edit2 className="w-4 h-4 text-white" />
            </button>
            <button
              onClick={() => removeBounty(bounty.id)}
              className="bg-red-500/90 hover:bg-red-600/90 backdrop-blur-sm p-2 rounded-full transition-colors"
              title="Delete bounty"
            >
              <Trash2 className="w-4 h-4 text-white" />
            </button>
          </div>
        )}
      </div>
      
      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-xl font-bold text-white">{bounty.name}</h3>
          {bounty.createdBy === user?.id && (
            <span className="text-xs text-primary bg-primary/10 px-3 py-1 rounded-full">
              Your bounty
            </span>
          )}
        </div>
        <p className="text-secondary text-sm mb-4">{bounty.description}</p>
        <div className="flex justify-between items-center gap-4">
          <div className="flex gap-2">
            {user ? (
              <button 
                onClick={handleShare}
                className="btn-secondary flex items-center gap-2 text-sm"
              >
                <Share2 size={16} />
                X
              </button>
            ) : (
              <button 
                onClick={onSignInClick}
                className="btn-primary flex items-center gap-2 text-sm"
              >
                <LogIn size={16} />
                Sign in to participate
              </button>
            )}
            {bounty.marketplaceUrl && (
              <a
                href={bounty.marketplaceUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary flex items-center gap-2 text-sm"
              >
                <ExternalLink size={16} />
                URL
              </a>
            )}
          </div>
          <span className="text-primary font-medium text-sm whitespace-nowrap">
            Prize: {bounty.prizeValue}
          </span>
        </div>
      </div>
    </div>
  );
};