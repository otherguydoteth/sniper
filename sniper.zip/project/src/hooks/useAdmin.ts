import { useState } from 'react';

export const useAdmin = () => {
  // In a real app, this would be connected to your authentication system
  const [isAdmin] = useState(true);
  return { isAdmin };
};