import { useBountyContext } from '../context/BountyContext';

export const useBounties = () => {
  return useBountyContext();
};