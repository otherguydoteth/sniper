import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, AuthState, UserRole } from '../types';
import * as db from '../services/db';

interface AuthContextType extends AuthState {
  login: (email: string, password: string) => Promise<void>;
  register: (username: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  updateProfile: (data: Partial<User>) => Promise<void>;
  promoteToAgent: (userId: string) => Promise<void>;
  demoteToUser: (userId: string) => Promise<void>;
  deleteUser: (userId: string) => Promise<void>;
  switchProfile: (user: User) => void;
  switchBackToMaster: () => void;
  masterUser: User | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    users: [],
    isAuthenticated: false,
    isAdmin: false,
    isAgent: false,
    isMaster: false,
  });
  const [masterUser, setMasterUser] = useState<User | null>(null);

  useEffect(() => {
    const initializeAuth = async () => {
      try {
        const database = await db.initDB();
        if (!database) {
          throw new Error('Failed to initialize database');
        }
        await db.ensureMasterExists();
        const users = await db.getAllUsers();
        setAuthState(prev => ({ ...prev, users }));
      } catch (error) {
        console.error('Error initializing auth:', error);
      }
    };

    initializeAuth();
  }, []);

  const login = async (email: string, password: string) => {
    try {
      if (!email || !password) {
        throw new Error('Whoopsies! Try again!');
      }

      const user = await db.getUserByEmail(email);
      if (!user) {
        throw new Error('Whoopsies! Try again!');
      }

      if (user.password !== password) {
        throw new Error('Whoopsies! Try again!');
      }

      setAuthState({ 
        ...authState,
        user, 
        isAuthenticated: true, 
        isAdmin: user.role === 'admin',
        isAgent: user.role === 'agent',
        isMaster: user.role === 'master'
      });

      if (user.role === 'master') {
        setMasterUser(user);
      }
    } catch (error) {
      throw new Error('Whoopsies! Try again!');
    }
  };

  const register = async (username: string, email: string, password: string) => {
    try {
      if (!username || !email || !password) {
        throw new Error('All fields are required');
      }

      const existingUser = await db.getUserByEmail(email);
      if (existingUser) {
        throw new Error('Email already registered');
      }

      const newUser: User = {
        id: `user_${Date.now()}`,
        username,
        email,
        password,
        role: 'user',
        gems: 0,
        status: 'meh',
        completedBounties: [],
        createdAt: new Date().toISOString(),
      };

      await db.addUser(newUser);
      const users = await db.getAllUsers();
      
      setAuthState({ 
        ...authState,
        user: newUser, 
        users,
        isAuthenticated: true, 
        isAdmin: false,
        isAgent: false,
        isMaster: false
      });
    } catch (error) {
      console.error('Error during registration:', error);
      throw error;
    }
  };

  const logout = () => {
    setAuthState({ 
      ...authState, 
      user: null, 
      isAuthenticated: false, 
      isAdmin: false,
      isAgent: false,
      isMaster: false
    });
    setMasterUser(null);
  };

  const updateProfile = async (data: Partial<User>) => {
    try {
      if (!authState.user) {
        throw new Error('No user logged in');
      }

      const updatedUser = { ...authState.user, ...data };
      await db.updateUser(updatedUser);
      const users = await db.getAllUsers();
      
      setAuthState({
        ...authState,
        user: updatedUser,
        users,
      });
    } catch (error) {
      console.error('Error updating profile:', error);
      throw error;
    }
  };

  const promoteToAgent = async (userId: string) => {
    try {
      if (!authState.isMaster) {
        throw new Error('Only master can promote users to agents');
      }

      const userToPromote = authState.users.find(u => u.id === userId);
      if (!userToPromote) {
        throw new Error('User not found');
      }

      const updatedUser = { ...userToPromote, role: 'agent' as UserRole };
      await db.updateUser(updatedUser);
      const users = await db.getAllUsers();
      
      setAuthState({
        ...authState,
        users,
      });
    } catch (error) {
      console.error('Error promoting user to agent:', error);
      throw error;
    }
  };

  const demoteToUser = async (userId: string) => {
    try {
      if (!authState.isMaster) {
        throw new Error('Only master can demote agents');
      }

      const userToDemote = authState.users.find(u => u.id === userId);
      if (!userToDemote) {
        throw new Error('User not found');
      }

      const updatedUser = { ...userToDemote, role: 'user' as UserRole };
      await db.updateUser(updatedUser);
      const users = await db.getAllUsers();
      
      setAuthState({
        ...authState,
        users,
      });
    } catch (error) {
      console.error('Error demoting agent:', error);
      throw error;
    }
  };

  const deleteUser = async (userId: string) => {
    try {
      if (!authState.isMaster) {
        throw new Error('Only master can delete users');
      }

      await db.deleteUser(userId);
      const users = await db.getAllUsers();
      
      setAuthState({
        ...authState,
        users,
      });
    } catch (error) {
      console.error('Error deleting user:', error);
      throw error;
    }
  };

  const switchProfile = (userToSwitch: User) => {
    if (!masterUser || masterUser.role !== 'master') {
      throw new Error('Only master can switch profiles');
    }

    setAuthState({
      ...authState,
      user: userToSwitch,
      isAuthenticated: true,
      isAdmin: userToSwitch.role === 'admin',
      isAgent: userToSwitch.role === 'agent',
      isMaster: userToSwitch.role === 'master'
    });
  };

  const switchBackToMaster = () => {
    if (!masterUser) {
      throw new Error('No master user found');
    }

    setAuthState({
      ...authState,
      user: masterUser,
      isAuthenticated: true,
      isAdmin: true,
      isAgent: true,
      isMaster: true
    });
  };

  return (
    <AuthContext.Provider value={{ 
      ...authState, 
      login, 
      register, 
      logout, 
      updateProfile,
      promoteToAgent,
      demoteToUser,
      deleteUser,
      switchProfile,
      switchBackToMaster,
      masterUser
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};