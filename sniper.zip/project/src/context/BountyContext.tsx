import React, { createContext, useState, useContext } from 'react';
import { Bounty } from '../types';
import { useAuth } from './AuthContext';

interface BountyContextType {
  activeBounties: Bounty[];
  completedBounties: Bounty[];
  addBounty: (bounty: Omit<Bounty, 'id' | 'createdBy'>) => void;
  editBounty: (id: string, bounty: Partial<Bounty>) => void;
  removeBounty: (id: string) => void;
  removeCompletedBounty: (id: string) => void;
  awardGems: (userId: string, amount: number) => Promise<void>;
  markBountyCompleted: (bountyId: string, userId: string) => Promise<void>;
  getBountiesByAgent: (agentId: string) => Bounty[];
}

const BountyContext = createContext<BountyContextType | undefined>(undefined);

export const BountyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, users, updateProfile } = useAuth();
  const [activeBounties, setActiveBounties] = useState<Bounty[]>([]);
  const [completedBounties, setCompletedBounties] = useState<Bounty[]>([]);

  const canManageBounties = user && (user.role === 'master' || user.role === 'agent');
  const isMaster = user?.role === 'master';

  const addBounty = (bounty: Omit<Bounty, 'id' | 'createdBy'>) => {
    if (!canManageBounties) {
      throw new Error('Only masters and agents can create bounties');
    }

    const newBounty = {
      ...bounty,
      id: Date.now().toString(),
      createdBy: user!.id,
      createdAt: new Date().toISOString(),
    };

    setActiveBounties([...activeBounties, newBounty]);
  };

  const editBounty = (id: string, updates: Partial<Bounty>) => {
    if (!canManageBounties) {
      throw new Error('Only masters and agents can edit bounties');
    }

    const bounty = activeBounties.find(b => b.id === id);
    if (!bounty) return;

    // Master can edit any bounty, agents can only edit their own
    if (!isMaster && bounty.createdBy !== user!.id) {
      throw new Error('Agents can only edit their own bounties');
    }

    if (updates.status === 'completed') {
      const updatedBounty = {
        ...bounty,
        ...updates,
        completedAt: new Date().toISOString(),
      };
      setCompletedBounties([...completedBounties, updatedBounty]);
      setActiveBounties(bounties => bounties.filter(b => b.id !== id));
    } else {
      setActiveBounties(bounties =>
        bounties.map(bounty =>
          bounty.id === id ? { ...bounty, ...updates } : bounty
        )
      );
    }
  };

  const removeBounty = (id: string) => {
    if (!canManageBounties) {
      throw new Error('Only masters and agents can remove bounties');
    }

    const bounty = activeBounties.find(b => b.id === id);
    if (!bounty) return;

    // Master can remove any bounty, agents can only remove their own
    if (!isMaster && bounty.createdBy !== user!.id) {
      throw new Error('Agents can only remove their own bounties');
    }

    setActiveBounties(bounties => bounties.filter(bounty => bounty.id !== id));
  };

  const removeCompletedBounty = (id: string) => {
    if (!canManageBounties) {
      throw new Error('Only masters and agents can remove completed bounties');
    }

    const bounty = completedBounties.find(b => b.id === id);
    if (!bounty) return;

    // Master can remove any completed bounty, agents can only remove their own
    if (!isMaster && bounty.createdBy !== user!.id) {
      throw new Error('Agents can only remove their own completed bounties');
    }

    setCompletedBounties(bounties => bounties.filter(bounty => bounty.id !== id));
  };

  const markBountyCompleted = async (bountyId: string, userId: string) => {
    if (!canManageBounties) {
      throw new Error('Only masters and agents can mark bounties as completed');
    }

    const bounty = activeBounties.find(b => b.id === bountyId);
    const winner = users.find(u => u.id === userId);
    
    // Master can complete any bounty, agents can only complete their own
    if (!isMaster && bounty?.createdBy !== user!.id) {
      throw new Error('Agents can only complete their own bounties');
    }
    
    if (bounty && winner) {
      const completedBounty = {
        ...bounty,
        winner: winner.username,
        completedAt: new Date().toISOString(),
        status: 'completed' as const,
      };
      
      setCompletedBounties([...completedBounties, completedBounty]);
      setActiveBounties(bounties => bounties.filter(b => b.id !== bountyId));

      // Award gems automatically when marking as completed
      if (winner) {
        await updateProfile({
          ...winner,
          completedBounties: [...(winner.completedBounties || []), bountyId],
          gems: winner.gems + bounty.gemReward
        });
      }
    }
  };

  const awardGems = async (userId: string, amount: number) => {
    if (!canManageBounties) {
      throw new Error('Only masters and agents can award gems');
    }

    const targetUser = users.find(u => u.id === userId);
    if (targetUser) {
      await updateProfile({
        ...targetUser,
        gems: targetUser.gems + amount,
      });
    }
  };

  const getBountiesByAgent = (agentId: string) => {
    // Master can see all bounties, agents only see their own
    if (isMaster) {
      return [...activeBounties, ...completedBounties];
    }
    return [...activeBounties, ...completedBounties].filter(
      bounty => bounty.createdBy === agentId
    );
  };

  return (
    <BountyContext.Provider value={{
      activeBounties,
      completedBounties,
      addBounty,
      editBounty,
      removeBounty,
      removeCompletedBounty,
      awardGems,
      markBountyCompleted,
      getBountiesByAgent,
    }}>
      {children}
    </BountyContext.Provider>
  );
};

export const useBountyContext = () => {
  const context = useContext(BountyContext);
  if (context === undefined) {
    throw new Error('useBountyContext must be used within a BountyProvider');
  }
  return context;
};