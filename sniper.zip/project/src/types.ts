export interface User {
  id: string;
  username: string;
  email: string;
  password: string;
  role: UserRole;
  status: UserStatus;
  gems: number;
  completedBounties: string[];
  createdBounties?: string[];
  profileImage?: string;
  createdAt: string;
}

export type UserRole = 'master' | 'agent' | 'user';
export type UserStatus = 'happy' | 'sad' | 'meh';
export type BountyStatus = 'active' | 'completed';
export type PrizeType = 'cash' | 'merchandise' | 'mystery';

export interface Bounty {
  id: string;
  name: string;
  description: string;
  imageUrl: string;
  marketplaceUrl?: string;
  prizeType: PrizeType;
  prizeValue: string;
  winner?: string;
  completedAt?: string;
  gemReward: number;
  status?: BountyStatus;
  createdBy: string;
  createdAt: string;
}