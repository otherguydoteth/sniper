/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: '#1D9BF0',
        secondary: '#71767B',
        'gray-dark': '#17181C',
        'gray-light': '#71767B',
        background: '#000000',
        'card-bg': '#16181C',
        'hover-bg': '#1D1F23',
        border: '#2F3336',
      },
    },
  },
  plugins: [],
};